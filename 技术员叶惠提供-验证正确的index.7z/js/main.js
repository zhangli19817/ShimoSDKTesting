async function main () {
  const fileGuid = 'JsCL5quySR11PhCk'

  const { data: token } = await axios({
    url: 'https://platform.shimodev.com/entry/oauth2/token',
    method: 'post',
    data: {
      clientId: '4e451e6af8b2b349',
      clientSecret: '340ede5bf45a4cf0a3ddfd131c3e2cb1',
      clientUserId: '1',
      grantType: 'client_credentials',
      scope: 'write',
      info: JSON.stringify({
        fileGuid: fileGuid,
        filePermissions: {
          editable: true,
          readonly: true,
          commentable: true
        }
      })
    }
  })

  window.shimoParameter = {
    token: token.accessToken,
    uploadToken: token.accessToken,
    uploadOrigin: '',
    uploadServer: 'oss',
    uploadMaxFileSize: 10,
    entrypoint: 'https://platform.shimodev.com/entry',
    user: {'id': 1, 'email': '', 'name': 'fghpdf', 'avatar': 'https://assets-cdn.shimo.im/static/unmd5/default-avatar-moke.png', 'namePinyin': null, 'status': 0, 'gender': null, 'lastNotificationId': null, 'clientUserId': '1', 'createdAt': '2018-12-12T06:54:20.000Z', 'updatedAt': '2019-03-10T18:08:18.000Z'},
    prepare: function () {
      return axios.get(window.shimoParameter.entrypoint + '/files/' + fileGuid, {
        headers: {
          authorization: 'bearer ' + window.shimoParameter.token
        }
      }).then(function (res) {
        window.shimoParameter.file = res.data
      }) // 未部署后端建议直接使用假数据
    // file: {"head":1,"content":"[[10, \"\\n\", \"line:\\\"init\\\"\"]]","guid":"i2piw5AxT4cRrgm4"}
    }
  }
  window.shimoParameter.prepare().then(function () {
    var cabinet = new ShimoCabinet.default({
      rootDom: document.getElementById('container'),
      sdkDocument: window.shimo.sdk.document,
      sdkCommon: window.shimo.sdk.common,
      user: window.shimoParameter.user,
      entrypoint: window.shimoParameter.entrypoint,
      token: window.shimoParameter.token,
      file: window.shimoParameter.file,
      editorOptions: {
        uploadConfig: {
          origin: window.shimoParameter.uploadOrigin,
          server: window.shimoParameter.uploadServer,
          token: window.shimoParameter.uploadToken,
          maxFileSize: window.shimoParameter.uploadMaxFileSize
        },
        downloadConfig: {
          origin: window.shimoParameter.uploadOrigin + '/upload2'
        }
      },
      plugins: ['Collaboration',
        'Comment',
        'History',
        'Uploader',
        'Gallery',
        'TableOfContent',
        'Shortcut'
      ],
      onSaveStatusChange: function (status) { console.log(status) }
    })
    cabinet.renderDocument()
// cabinet.destroyDocument(); 销毁
  })
}
main()
